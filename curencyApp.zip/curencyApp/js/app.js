// 1846fbf6ecebfc6705cf42a5dc1f835b
$(document).ready(function (){
    $.get("http://data.fixer.io/api/latest?access_key=1846fbf6ecebfc6705cf42a5dc1f835b&format=1", function(data){
        $("#loading").hide();
        
        let rateKeys = Object.keys(data.rates);
        let rateView = "<table>";
        rateView = rateKeys.map((countryCode)=>{
              let rateValue = data.rates[countryCode];
            return`
                <tr>
                    <td>${countryCode}</td> <td>${rateValue}</td>
                </tr>
            `;
        }).join();

        rateView += "</table>";

        $("#result").html("<h2>"+data.base+"</h2>").append("<p>Date:"+ data.date+ "</p>").append(rateView);
    });
});



